# First-Semester-Final

Here is the final exam project for Computer Science I.  You will have 5 days in the computer lab to complete this beginning Monday December 12th and concluding Friday December 16th.  Your preformance will be based on the project rubric that I shared with you through Showbie a few days ago.  You are encouraged to work with each other, but keep in mind that you are responsible for your own repository.

## List of Subtle and Not Subtle Facts
  -  There are 3 separate README files explaining 3 separate classes for you to implment.
  -  That means 1 README file for each class.
  -  Here is another bullet point emphasizing how logical that is...
  -  You must upload all 3 files to receive full credit.

## Tips
  -  Bring your notes and worksheets. You have all the tools and information to get the job done. It may take some refreshing on old concepts so be prepared.
  -  Plan and work with classmates after school in the library. Discuss potential solutions to the challenges so you do not run out of time on Friday to type.
  -  Over the weekend review your code and practice explaining how each function works.
  -  Read my instructions and do not try to write down BS before you understand what it wants you to do (This applies to all life basically.)
  
