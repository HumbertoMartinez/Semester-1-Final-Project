class Item{
  //Fill in the item class below this comment.
  constructor(n,p,s){
    this.name = n;
    this.price = p;
    this.shipping = s;
  }
}

//Create your three test items below this comment.
this.item = new Item("Nexus Computer" 200,2)
this.item = new Item("Legos" 45,1)
this.item = new Item("Turtlebeach Headset" 250,7)
}
