class Cart{
  //What is the first part of every class? Type it below.
constructor(itemList,itemQuantity){
  this.itemList = itemList;
  this.itemQuantity = itemQuantity;
}

  //Type the instance functions below this comment.
addItem(i,q){
  this.itemList.push(i);
  this.itemQuantity.push(q);
}
totalCart(){
  let total = 0;
  for(a=0;a<itemList.length;a++)

  item.push(total);

}
